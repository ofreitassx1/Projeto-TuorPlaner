import express from 'express';
import pool from './db.js';
import bodyParser from 'body-parser';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Configurando o servidor para servir arquivos estáticos do frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// Rota principal que redireciona para a página inicial
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/html/home.html'));
});

// Rota direta para a página do Rio
app.get('/rio.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/html/rio.html'));
});

// Rotas para viagens
// Obter todas as viagens
app.get('/viagens', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM viagens');
    res.json(result.rows);
  } catch (err) {
    console.error('Erro ao buscar viagens:', err);
    res.status(500).json({ error: 'Erro ao buscar viagens' });
  }
});

// Obter uma viagem específica
app.get('/viagens/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM viagens WHERE id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Viagem não encontrada' });
    }
    
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Erro ao buscar viagem:', err);
    res.status(500).json({ error: 'Erro ao buscar viagem' });
  }
});

// Criar uma nova viagem
app.post('/viagens', async (req, res) => {
  try {
    const { destino, descricao, preco, imagem_url } = req.body;
    const result = await pool.query(
      'INSERT INTO viagens (destino, descricao, preco, imagem_url) VALUES ($1, $2, $3, $4) RETURNING *',
      [destino, descricao, preco, imagem_url]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Erro ao criar viagem:', err);
    res.status(500).json({ error: 'Erro ao criar viagem' });
  }
});

// Atualizar uma viagem existente
app.put('/viagens/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { destino, descricao, preco, imagem_url } = req.body;
    
    const result = await pool.query(
      'UPDATE viagens SET destino = $1, descricao = $2, preco = $3, imagem_url = $4 WHERE id = $5 RETURNING *',
      [destino, descricao, preco, imagem_url, id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Viagem não encontrada' });
    }
    
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Erro ao atualizar viagem:', err);
    res.status(500).json({ error: 'Erro ao atualizar viagem' });
  }
});

// Excluir uma viagem
app.delete('/viagens/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM viagens WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Viagem não encontrada' });
    }
    
    res.json({ message: 'Viagem excluída com sucesso' });
  } catch (err) {
    console.error('Erro ao excluir viagem:', err);
    res.status(500).json({ error: 'Erro ao excluir viagem' });
  }
});

// Rota para salvar pagamentos
app.post('/pagamentos', async (req, res) => {
  try {
    const { 
      nome_completo, 
      email, 
      endereco, 
      cidade, 
      estado, 
      codigo_postal, 
      nome_no_cartao, 
      numero_cartao, 
      mes_validade, 
      ano_validade, 
      cvv, 
      metodo_pagamento, 
      valor_total 
    } = req.body;
    
    const result = await pool.query(
      `INSERT INTO pagamentos (
        nome_completo, email, endereco, cidade, estado, codigo_postal, 
        nome_no_cartao, numero_cartao, mes_validade, ano_validade, cvv, 
        metodo_pagamento, valor_total
      ) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *`,
      [
        nome_completo, email, endereco, cidade, estado, codigo_postal,
        nome_no_cartao, numero_cartao, mes_validade, ano_validade, cvv,
        metodo_pagamento, valor_total
      ]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Erro ao salvar pagamento:', err);
    res.status(500).json({ error: 'Erro ao salvar pagamento' });
  }
});

// Rota para salvar dados da sessão de viagem
app.post('/sessao-viagem', async (req, res) => {
  try {
    const { 
      local_partida, 
      destino, 
      data_partida, 
      data_retorno, 
      numero_passageiros, 
      numero_contato, 
      numero_passaporte,
      classe,
      numero_assentos
    } = req.body;
    
    // Aqui você pode criar uma nova tabela para armazenar esses dados
    // ou adicionar esses campos à tabela de viagens existente
    const result = await pool.query(
      `INSERT INTO sessao_viagem (
        local_partida, destino, data_partida, data_retorno, 
        numero_passageiros, numero_contato, numero_passaporte,
        classe, numero_assentos
      ) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
      [
        local_partida, destino, data_partida, data_retorno,
        numero_passageiros, numero_contato, numero_passaporte,
        classe, numero_assentos
      ]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Erro ao salvar sessão de viagem:', err);
    res.status(500).json({ error: 'Erro ao salvar sessão de viagem' });
  }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Servidor rodando em http://localhost:${PORT}`));
