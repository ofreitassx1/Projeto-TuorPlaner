import 'dotenv/config';
import pkg from 'pg';
const { Pool } = pkg;

// Lê a URL do banco do ambiente
const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error('DATABASE_URL não definida. Crie um arquivo .env no diretório backend com DATABASE_URL=...');
}

// Criando o pool de conexões
const pool = new Pool({
  connectionString: databaseUrl,
  ssl: {
    // Necessário para conexões SSL com Neon
    rejectUnauthorized: false
  }
});

// Função para testar a conexão (executa uma vez na inicialização)
async function testConnection() {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT NOW()');
    console.log('✅ Conectado ao PostgreSQL!', result.rows[0]);
    client.release();
  } catch (err) {
    console.error('❌ Erro ao conectar ao banco:', err);
  }
}

testConnection();

export default pool;
