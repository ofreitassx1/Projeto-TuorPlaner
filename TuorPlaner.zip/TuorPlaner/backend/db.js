import pg from 'pg';
import dotenv from 'dotenv';

// Carrega as variáveis de ambiente do arquivo .env
dotenv.config();

// Cria um pool de conexões com o banco de dados
const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false // Necessário para conexões SSL com alguns provedores
  }
});

// Teste de conexão
pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('❌ Erro ao conectar ao banco de dados:', err);
  } else {
    console.log('✅ Conexão com o banco de dados estabelecida com sucesso!');
    console.log(`🕒 Hora do servidor: ${res.rows[0].now}`);
  }
});

export default pool;