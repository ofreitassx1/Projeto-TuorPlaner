import pool from './db.js';

// Script para criar as tabelas no banco de dados
async function initDatabase() {
  try {
    // Criar tabela de viagens (se ainda não existir)
    await pool.query(`
      CREATE TABLE IF NOT EXISTS viagens (
        id SERIAL PRIMARY KEY,
        destino TEXT NOT NULL,
        descricao TEXT,
        preco DECIMAL(10,2) NOT NULL,
        imagem_url TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Criar tabela de pagamentos
    await pool.query(`
      CREATE TABLE IF NOT EXISTS pagamentos (
        id SERIAL PRIMARY KEY,
        nome_completo TEXT NOT NULL,
        email TEXT NOT NULL,
        endereco TEXT NOT NULL,
        cidade TEXT NOT NULL,
        estado TEXT NOT NULL,
        codigo_postal TEXT NOT NULL,
        nome_no_cartao TEXT NOT NULL,
        numero_cartao TEXT NOT NULL,
        mes_validade TEXT NOT NULL,
        ano_validade TEXT NOT NULL,
        cvv TEXT NOT NULL,
        metodo_pagamento TEXT NOT NULL,
        valor_total DECIMAL(10,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela pagamentos criada com sucesso!');

    // Criar tabela de sessão de viagem
    await pool.query(`
      CREATE TABLE IF NOT EXISTS sessao_viagem (
        id SERIAL PRIMARY KEY,
        local_partida TEXT NOT NULL,
        destino TEXT NOT NULL,
        data_partida DATE NOT NULL,
        data_retorno DATE NOT NULL,
        numero_passageiros INTEGER NOT NULL,
        numero_contato TEXT NOT NULL,
        numero_passaporte TEXT,
        classe TEXT,
        numero_assentos INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✅ Tabela sessao_viagem criada com sucesso!');

    console.log('🎉 Inicialização do banco de dados concluída!');
  } catch (err) {
    console.error('❌ Erro ao inicializar o banco de dados:', err);
  } finally {
    // Não fechamos a conexão para garantir que as alterações sejam persistidas
    console.log('✅ Operação concluída no banco de dados Neon');
  }
}

// Executar a inicialização
initDatabase();