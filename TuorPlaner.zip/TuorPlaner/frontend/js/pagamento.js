// Captura o submit do formulário e envia para o backend
(function () {
  const formPagamento = document.getElementById('form-pagamento');
  const formSessao = document.getElementById('form-sessao');
  if (!formPagamento) return;

  // Lê ?valor= da URL e exibe no resumo
  const params = new URLSearchParams(window.location.search);
  const valorParam = params.get('valor');
  const valorHidden = document.getElementById('valor_total');
  const valorView = document.getElementById('valor_total_view');
  if (valorParam && !isNaN(Number(valorParam))) {
    const num = Number(valorParam);
    if (valorHidden) valorHidden.value = String(num);
    if (valorView) valorView.textContent = num.toFixed(2).replace('.', ',');
  }

  formPagamento.addEventListener('submit', async function (e) {
    e.preventDefault();

    // Monta o payload do pagamento
    const payload = {
      nome_completo: document.getElementById('nome_completo')?.value || '',
      email: document.getElementById('email')?.value || '',
      endereco: document.getElementById('endereco')?.value || '',
      cidade: document.getElementById('cidade')?.value || '',
      estado: document.getElementById('estado')?.value || '',
      codigo_postal: document.getElementById('codigo_postal')?.value || '',
      nome_no_cartao: document.getElementById('nome_no_cartao')?.value || '',
      numero_cartao: document.getElementById('numero_cartao')?.value || '',
      mes_validade: document.getElementById('mes_validade')?.value || '',
      ano_validade: document.getElementById('ano_validade')?.value || '',
      cvv: document.getElementById('cvv')?.value || '',
      metodo_pagamento: 'cartao',
      valor_total: Number(document.getElementById('valor_total')?.value || 0)
    };

    try {
      const res = await fetch('/pagamentos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        alert('Erro ao processar pagamento: ' + (err.error || res.statusText));
        return;
      }

      const data = await res.json();
      alert('Pagamento registrado! ID: ' + data.id);

      // Opcional: enviar dados da sessão de viagem, se preenchidos
      if (formSessao) {
        const sessaoPayload = {
          local_partida: document.getElementById('local_partida')?.value || '',
          destino: document.getElementById('destino')?.value || '',
          data_partida: document.getElementById('data_partida')?.value || '',
          data_retorno: document.getElementById('data_retorno')?.value || '',
          numero_passageiros: document.getElementById('numero_passageiros')?.value || '',
          numero_contato: document.getElementById('numero_contato')?.value || '',
          numero_passaporte: document.getElementById('numero_passaporte')?.value || '',
          classe: document.getElementById('classe')?.value || '',
          numero_assentos: document.getElementById('numero_assentos')?.value || ''
        };

        fetch('/sessao-viagem', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(sessaoPayload)
        }).catch(() => {});
      }

      formPagamento.reset();
    } catch (error) {
      alert('Falha de rede ao enviar pagamento.');
    }
  });
})();


